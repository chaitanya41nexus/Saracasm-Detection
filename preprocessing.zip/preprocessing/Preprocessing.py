
#step 2: pre-process
import nltk
from nltk.tokenize import *

def filterTweets(list): # function to filter some useless information # filter the tag?
    item = ' '.join(word.lower() for word in list.split() \
                        if not word.startswith('@') and \
                        not word.startswith('RT') and \
                        not word.startswith('#') and \
                        not word.startswith('http') )
    return item

def generateSet(filename):
    f = open(filename,'r',encoding='utf8')
    tweets = []
    rawline = f.readline() #read the file by line
    while rawline:
        tweets.append(rawline)
        rawline = f.readline() 

    print(len(tweets)) #print the element number of result list
    for i in range(0,10): #print the first 10 reviews
        print(tweets[i])
    f.close()  

    tokens = []
    for tweet in tweets:
        token = []
        token_sent = []
        sents = []
        tweet = filterTweets(tweet.lower()) #lower case, filtering
        sents = sent_tokenize(tweet) 
        for sent in sents:
            token = word_tokenize(sent)
            token_sent.append(token)
        tokens.append(token_sent)

    count = 0
    for tweet in tokens:
        if count > 10:
            break
        for sentence in tweet:
            print(sentence)
        count = count + 1

    return tokens

trainset = generateSet("trainset.txt")#read training set
sarcasm_pos = generateSet("sarcasm_pos.txt")#read pos dataset
sarcasm_neg = generateSet("sarcasm_neg.txt")#read neg dataset
freshdata = generateSet("freshdata.txt")#read fresh dataset

# label the data
tagset = ([(sent, 'pos') for sent in sarcasm_pos] +
          [(sent, 'neg') for sent in sarcasm_neg])

# put the list into random order
import random
random.shuffle(tagset)
print(tagset[:20])

# step 3: process data